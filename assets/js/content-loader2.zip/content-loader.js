function loadContent(jsonFile, addToHistory = true) {
    fetch(jsonFile)
        .then(response => response.json())
        .then(data => {
            console.log(`📖 ${jsonFile} をロード:`, data);
            displayContent(data);
            saveLastViewed(jsonFile);

            if (addToHistory) {
                history.pushState({ page: jsonFile }, "", `?page=${jsonFile}`);
            }
        })
        .catch(error => console.error(`⚠ コンテンツの読み込みに失敗: ${jsonFile}`, error));
}

function displayContent(data) {
    const titleElement = document.getElementById("content-title");
    const bodyElement = document.getElementById("content-body");

    titleElement.textContent = data.title;
    bodyElement.innerHTML = "";

    if (Array.isArray(data.description)) {
        data.description.forEach(item => {
            createContentElement(item, bodyElement);
        });
    }

    if (Array.isArray(data.sections)) {
        data.sections.forEach(section => {
            const sectionElement = document.createElement("section");
            
            if (section.title) {
                const sectionTitle = document.createElement("h2");
                sectionTitle.textContent = section.title;
                sectionElement.appendChild(sectionTitle);
            }

            if (Array.isArray(section.content)) {
                section.content.forEach(item => {
                    createContentElement(item, sectionElement);
                });
            }

            bodyElement.appendChild(sectionElement);
        });
    }
}

function createContentElement(item, parentElement) {
    let element;

    if (item.type === "p") {
        element = document.createElement("p");

        // text を paragraphs に変換
        if (item.text) {
        item.paragraphs = [item.text];
        }       

        if (Array.isArray(item.paragraphs)) {
            item.paragraphs.forEach(paragraph => {
                const pElement = document.createElement("p");
                pElement.textContent = paragraph;
                parentElement.appendChild(pElement); // ここで直接親要素に追加
            });
        }
        
        if (item.attributes) {
            applyAttributes(element, item.attributes);
        }
    } else if (item.type === "list") {
        element = document.createElement(item.ordered ? "ol" : "ul");

        item.items.forEach(listItem => {
            const li = document.createElement("li");

            if (typeof listItem === "string") {
                li.textContent = listItem;
            } else if (typeof listItem === "object") {
                if ("text" in listItem) {
                    const strong = document.createElement("strong");
                    strong.textContent = listItem.text;
                    li.appendChild(strong);
                }
                if ("details" in listItem) {
                    const details = document.createElement("p");
                    details.textContent = listItem.details;
                    li.appendChild(details);
                }
                if ("sample" in listItem) {
                    const sample = document.createElement("p");
                    sample.style.fontStyle = "italic";
                    sample.textContent = `例: ${listItem.sample}`;
                    li.appendChild(sample);
                }
            }

            element.appendChild(li);
        });
    } else if (item.type === "code") {
        element = document.createElement("pre");
        const code = document.createElement("code");
        code.classList.add(item.language || "plaintext");
        code.textContent = item.content;
        element.appendChild(code);
    }

    if (element) {
        parentElement.appendChild(element);
    }
}


function applyAttributes(element, attributes) {
    Object.entries(attributes).forEach(([key, value]) => {
        if (key === "class") {
            element.classList.add(value);
        } else if (key === "boldtext") {
            const strong = document.createElement("strong");
            strong.textContent = value;
            element.prepend(strong);
        } else {
            element.setAttribute(key, value);
        }
    });
}

function saveLastViewed(jsonFile) {
    localStorage.setItem("lastViewed", jsonFile);
}

document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    const pageFromURL = urlParams.get("page");
    const lastViewed = localStorage.getItem("lastViewed");

    if (pageFromURL) {
        loadContent(pageFromURL, false);
    } else if (lastViewed) {
        loadContent(lastViewed, false);
    } else {
        loadContent("data/preface/preface.json", false);
    }
});

window.addEventListener("popstate", function (event) {
    if (event.state && event.state.page) {
        loadContent(event.state.page, false);
    }
});
